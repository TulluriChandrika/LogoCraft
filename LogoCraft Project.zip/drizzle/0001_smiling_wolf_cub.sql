CREATE TABLE `logos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`prompt` text NOT NULL,
	`style` varchar(64) NOT NULL,
	`colorPalette` varchar(64) NOT NULL,
	`industry` varchar(64) NOT NULL,
	`imageUrl` text NOT NULL,
	`fileKey` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `logos_id` PRIMARY KEY(`id`)
);
