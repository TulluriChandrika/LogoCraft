import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { ArrowLeft, Download, Clock, Wand2 } from "lucide-react";
import { toast } from "sonner";

interface SessionLogo {
  id: number;
  imageUrl: string;
  prompt: string;
  style: string;
  colorPalette: string;
  industry: string;
  createdAt: string;
}

const STORAGE_KEY = "logocraft_session_logos";

function getSessionLogos(): SessionLogo[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as SessionLogo[];
  } catch {
    return [];
  }
}

export default function History() {
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const [sessionLogos, setSessionLogos] = useState<SessionLogo[]>(() => getSessionLogos());

  const refreshSessionLogos = useCallback(() => {
    setSessionLogos(getSessionLogos());
  }, []);

  useEffect(() => {
    refreshSessionLogos();
  }, [refreshSessionLogos]);

  const historyQuery = trpc.logo.history.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Merge DB history with session history
  const dbLogos = isAuthenticated && historyQuery.data?.logos
    ? (historyQuery.data.logos as unknown as SessionLogo[])
    : [];

  const seenUrls = new Set<string>();
  const mergedLogos: SessionLogo[] = [];
  for (const logo of [...dbLogos, ...sessionLogos]) {
    if (!seenUrls.has(logo.imageUrl)) {
      seenUrls.add(logo.imageUrl);
      mergedLogos.push(logo);
    }
  }

  const handleDownload = async (url: string) => {
    if (!url) return;
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Download failed (${response.status})`);
      }
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = `logocraft-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(blobUrl);
      toast.success("Logo downloaded!");
    } catch {
      toast.error("Failed to download logo. Please try again.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-background/80 border-b border-border/40">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#0A2463] flex items-center justify-center">
              <Wand2 className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
              LogoCraft
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate("/")}
              className="gap-1.5 border-[#1B3B6F]/30 hover:border-[#1B3B6F] hover:bg-[#1B3B6F]/5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Generator
            </Button>
          </div>
        </div>
      </nav>

      {/* History Section */}
      <section className="container py-8 md:py-12">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
          >
            <div className="flex items-center gap-3 mb-8">
              <Clock className="w-6 h-6 text-[#1B3B6F]" />
              <h1 className="text-2xl md:text-3xl font-bold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
                Generation History
              </h1>
            </div>
          </motion.div>

          {isAuthenticated && historyQuery.isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="aspect-square bg-secondary/50 animate-pulse" />
                  <div className="p-3 space-y-2">
                    <div className="h-3 bg-secondary/80 rounded w-3/4 animate-pulse" />
                    <div className="h-3 bg-secondary/80 rounded w-1/2 animate-pulse" />
                  </div>
                </Card>
              ))}
            </div>
          ) : mergedLogos.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {mergedLogos.map((logo, index) => (
                <motion.div
                  key={logo.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                    <div className="aspect-square bg-secondary/50">
                      <img
                        src={logo.imageUrl}
                        alt={`Logo - ${logo.prompt}`}
                        className="w-full h-full object-contain p-2"
                      />
                    </div>
                    <div className="p-3 space-y-2">
                      <p className="text-xs text-muted-foreground line-clamp-2 min-h-[2rem]">
                        {logo.prompt}
                      </p>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {logo.style}
                        </Badge>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {logo.colorPalette}
                        </Badge>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {logo.industry}
                        </Badge>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full mt-1 h-7 gap-1 text-xs text-[#1B3B6F] hover:bg-[#1B3B6F]/10"
                        onClick={() => handleDownload(logo.imageUrl)}
                      >
                        <Download className="w-3 h-3" />
                        Download
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              <div className="w-16 h-16 rounded-2xl bg-[#0A2463]/10 flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-[#1B3B6F]/60" />
              </div>
              <h3 className="text-lg font-semibold mb-2" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
                No logos generated yet
              </h3>
              <p className="text-sm text-muted-foreground mb-6">
                Head back to the generator and create your first logo!
              </p>
              <Button onClick={() => navigate("/")} className="gap-2 bg-[#0A2463] hover:bg-[#1B3B6F] text-white">
                <Wand2 className="w-4 h-4" />
                Go to Generator
              </Button>
            </motion.div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/40 py-8 mt-auto">
        <div className="container text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-6 h-6 rounded-md bg-[#0A2463] flex items-center justify-center">
              <Wand2 className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-sm font-semibold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
              LogoCraft
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            AI-powered logo generation. Design the perfect brand identity.
          </p>
        </div>
      </footer>
    </div>
  );
}
