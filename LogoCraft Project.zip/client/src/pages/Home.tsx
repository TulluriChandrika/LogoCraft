import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles,
  Download,
  Clock,
  Palette,
  Layers,
  Building2,
  Wand2,
} from "lucide-react";
import { toast } from "sonner";

const STYLE_OPTIONS = ["Modern", "Vintage", "Geometric", "Minimalist", "Bold", "Playful"] as const;
const COLOR_PALETTE_OPTIONS = ["Monochrome", "Vibrant", "Pastel", "Earth Tones", "Neon"] as const;
const INDUSTRY_OPTIONS = ["Tech", "Food", "Fashion", "Finance", "Health", "Creative"] as const;

interface SessionLogo {
  id: number;
  imageUrl: string;
  prompt: string;
  style: string;
  colorPalette: string;
  industry: string;
  createdAt: string;
}

const STORAGE_KEY = "logocraft_session_logos";

function getSessionLogos(): SessionLogo[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as SessionLogo[];
  } catch {
    return [];
  }
}

function saveSessionLogo(logo: SessionLogo) {
  const logos = getSessionLogos();
  logos.unshift(logo);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(logos.slice(0, 50)));
}

export default function Home() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [prompt, setPrompt] = useState("");
  const [selectedStyle, setSelectedStyle] = useState<string | null>(null);
  const [selectedPalette, setSelectedPalette] = useState<string | null>(null);
  const [selectedIndustry, setSelectedIndustry] = useState<string | null>(null);
  const [generatedUrl, setGeneratedUrl] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [sessionLogos, setSessionLogos] = useState<SessionLogo[]>(() => getSessionLogos());

  // Refresh session logos when history panel is opened
  const refreshSessionLogos = useCallback(() => {
    setSessionLogos(getSessionLogos());
  }, []);

  useEffect(() => {
    if (showHistory) {
      refreshSessionLogos();
    }
  }, [showHistory, refreshSessionLogos]);

  const generateMutation = trpc.logo.generate.useMutation({
    onSuccess: (data) => {
      if (data.success && data.imageUrl) {
        setGeneratedUrl(data.imageUrl);

        const sessionLogo: SessionLogo = {
          id: Date.now(),
          imageUrl: data.imageUrl,
          prompt: prompt.trim(),
          style: selectedStyle!,
          colorPalette: selectedPalette!,
          industry: selectedIndustry!,
          createdAt: new Date().toISOString(),
        };
        saveSessionLogo(sessionLogo);
        setSessionLogos(getSessionLogos());

        toast.success("Logo generated successfully!");
      }
    },
    onError: (error) => {
      toast.error(error.message || "Failed to generate logo. Please try again.");
    },
  });

  const historyQuery = trpc.logo.history.useQuery(undefined, {
    enabled: showHistory && isAuthenticated,
  });

  const handleGenerate = () => {
    if (!isAuthenticated) {
      startLogin();
      return;
    }
    if (!prompt.trim()) {
      toast.error("Please enter a description for your logo.");
      return;
    }
    if (!selectedStyle) {
      toast.error("Please select a logo style.");
      return;
    }
    if (!selectedPalette) {
      toast.error("Please select a color palette.");
      return;
    }
    if (!selectedIndustry) {
      toast.error("Please select an industry/theme.");
      return;
    }

    generateMutation.mutate({
      prompt: prompt.trim(),
      style: selectedStyle as (typeof STYLE_OPTIONS)[number],
      colorPalette: selectedPalette as (typeof COLOR_PALETTE_OPTIONS)[number],
      industry: selectedIndustry as (typeof INDUSTRY_OPTIONS)[number],
    });
  };

  const handleDownload = async (url: string) => {
    if (!url) return;
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Download failed (${response.status})`);
      }

      const contentType = response.headers.get("content-type") || "";
      if (!contentType.includes("image") && !contentType.includes("octet-stream")) {
        console.warn("Content-type may not be an image:", contentType);
      }

      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = `logocraft-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(blobUrl);
      toast.success("Logo downloaded!");
    } catch {
      toast.error("Failed to download logo. Please try again.");
    }
  };

  const isFormValid = prompt.trim() && selectedStyle && selectedPalette && selectedIndustry;

  // Merge authenticated DB history with local session history
  const dbLogos = showHistory && isAuthenticated && historyQuery.data?.logos
    ? (historyQuery.data.logos as unknown as SessionLogo[])
    : [];

  // Deduplicate by URL, prefer DB entries, fall back to session entries
  const seenUrls = new Set<string>();
  const mergedLogos: SessionLogo[] = [];
  for (const logo of [...dbLogos, ...sessionLogos]) {
    if (!seenUrls.has(logo.imageUrl)) {
      seenUrls.add(logo.imageUrl);
      mergedLogos.push(logo);
    }
  }
  const displayedLogos = mergedLogos;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-background/80 border-b border-border/40">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#0A2463] flex items-center justify-center">
              <Wand2 className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
              LogoCraft
            </span>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-muted-foreground hidden sm:inline">
                  Welcome, {user?.name || "Designer"}
                </span>
              </>
            ) : null}
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate("/history")}
              className="gap-1.5 border-[#1B3B6F]/30 hover:border-[#1B3B6F] hover:bg-[#1B3B6F]/5"
            >
              <Clock className="w-3.5 h-3.5 text-[#21295C]" />
              History
            </Button>
            {!isAuthenticated && (
              <Button
                size="sm"
                onClick={() => startLogin()}
                className="gap-1.5 bg-[#0A2463] hover:bg-[#1B3B6F] text-white"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Sign In
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1B3B6F]/[0.05] via-background to-[#0A2463]/[0.04]" />
        <div className="relative container py-16 md:py-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
          >
            <Badge variant="secondary" className="mb-4 text-xs font-medium tracking-wide uppercase">
              AI-Powered Design
            </Badge>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-tight mb-4">
              Craft Your Perfect{" "}
              <span className="text-[#1B3B6F]">Logo</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Describe your vision, select your style, and let AI bring your brand identity to life
              in seconds.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Generator */}
      <section className="container pb-16">
        <div className="grid lg:grid-cols-5 gap-8">
          {/* Left Panel - Input */}
          <div className="lg:col-span-3 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="shadow-lg shadow-primary/[0.04] border-border/60">
                <CardContent className="p-6 md:p-8 space-y-6">
                  {/* Prompt Input */}
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-foreground flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#1B3B6F]" />
                      Describe Your Logo
                    </label>
                    <Input
                      placeholder="e.g., A sleek fox head with flowing lines for a tech startup"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="h-12 text-base placeholder:text-muted-foreground/60"
                    />
                  </div>

                  <Separator />

                  {/* Style Selector */}
                  <div className="space-y-3">
                    <label className="text-sm font-semibold text-foreground flex items-center gap-2">
                      <Layers className="w-4 h-4 text-[#1B3B6F]" />
                      Logo Style
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {STYLE_OPTIONS.map((style) => (
                        <button
                          key={style}
                          onClick={() => setSelectedStyle(style)}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 border ${
                            selectedStyle === style
                              ? "bg-[#0A2463] text-white border-[#0A2463] shadow-md shadow-[#0A2463]/20"
                              : "bg-secondary/50 text-secondary-foreground border-border hover:border-[#1B3B6F]/40 hover:bg-[#1B3B6F]/5"
                          }`}
                        >
                          {style}
                        </button>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Color Palette Selector */}
                  <div className="space-y-3">
                    <label className="text-sm font-semibold text-foreground flex items-center gap-2">
                      <Palette className="w-4 h-4 text-[#1B3B6F]" />
                      Color Palette
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {COLOR_PALETTE_OPTIONS.map((palette) => (
                        <button
                          key={palette}
                          onClick={() => setSelectedPalette(palette)}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 border ${
                            selectedPalette === palette
                              ? "bg-[#0A2463] text-white border-[#0A2463] shadow-md shadow-[#0A2463]/20"
                              : "bg-secondary/50 text-secondary-foreground border-border hover:border-[#1B3B6F]/40 hover:bg-[#1B3B6F]/5"
                          }`}
                        >
                          {palette}
                        </button>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Industry Selector */}
                  <div className="space-y-3">
                    <label className="text-sm font-semibold text-foreground flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-[#1B3B6F]" />
                      Industry / Theme
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {INDUSTRY_OPTIONS.map((industry) => (
                        <button
                          key={industry}
                          onClick={() => setSelectedIndustry(industry)}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 border ${
                            selectedIndustry === industry
                              ? "bg-[#0A2463] text-white border-[#0A2463] shadow-md shadow-[#0A2463]/20"
                              : "bg-secondary/50 text-secondary-foreground border-border hover:border-[#1B3B6F]/40 hover:bg-[#1B3B6F]/5"
                          }`}
                        >
                          {industry}
                        </button>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Generate Button */}
                  <Button
                    onClick={handleGenerate}
                    disabled={!isFormValid || generateMutation.isPending}
                    size="lg"
                    className="w-full h-12 text-base font-semibold gap-2 bg-[#0A2463] hover:bg-[#1B3B6F] text-white shadow-lg shadow-[#0A2463]/20 transition-all duration-200"
                  >
                    {generateMutation.isPending ? (
                      <>
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        >
                          <Palette className="w-5 h-5" />
                        </motion.div>
                        Generating Your Logo...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        Generate Logo
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Right Panel - Output */}
          <div className="lg:col-span-2 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="shadow-lg shadow-primary/[0.04] border-border/60">
                <CardContent className="p-6 md:p-8">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
                    <Wand2 className="w-5 h-5 text-[#1B3B6F]" />
                    Generated Logo
                  </h3>

                  <AnimatePresence mode="wait">
                    {generateMutation.isPending ? (
                      <motion.div
                        key="loading"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="aspect-square rounded-xl bg-gradient-to-br from-secondary to-accent flex items-center justify-center"
                      >
                        <div className="text-center space-y-4">
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                          >
                            <div className="w-16 h-16 rounded-full border-4 border-[#1B3B6F]/20 border-t-[#0A2463] mx-auto" />
                          </motion.div>
                          <p className="text-sm text-muted-foreground font-medium">
                            Crafting your logo...
                          </p>
                          <p className="text-xs text-muted-foreground/70">
                            This may take 10-20 seconds
                          </p>
                        </div>
                      </motion.div>
                    ) : generatedUrl ? (
                      <motion.div
                        key="result"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
                        className="space-y-4"
                      >
                        <div className="aspect-square rounded-xl overflow-hidden bg-secondary/50 border border-border/40">
                          <img
                            src={generatedUrl}
                            alt="Generated Logo"
                            className="w-full h-full object-contain"
                          />
                        </div>
                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleDownload(generatedUrl)}
                            className="flex-1 gap-2 bg-[#0A2463] hover:bg-[#1B3B6F] text-white"
                          >
                            <Download className="w-4 h-4" />
                            Download PNG
                          </Button>
                          <Button
                            onClick={handleGenerate}
                            variant="outline"
                            className="gap-2 border-[#1B3B6F]/30 hover:border-[#1B3B6F] hover:bg-[#1B3B6F]/5"
                          >
                            <Sparkles className="w-4 h-4 text-[#21295C]" />
                            Regenerate
                          </Button>
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="empty"
                        className="aspect-square rounded-xl bg-gradient-to-br from-secondary to-accent flex items-center justify-center"
                      >
                        <div className="text-center space-y-3 px-6">
                          <div className="w-12 h-12 rounded-xl bg-[#0A2463]/10 flex items-center justify-center mx-auto">
                            <Wand2 className="w-6 h-6 text-[#1B3B6F]/60" />
                          </div>
                          <p className="text-sm text-muted-foreground font-medium">
                            Your logo will appear here
                          </p>
                          <p className="text-xs text-muted-foreground/70">
                            Fill in the options and click Generate
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>

        {/* History Section */}
        <AnimatePresence>
          {showHistory && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
              className="mt-12"
            >
              <Card className="shadow-lg shadow-primary/[0.04] border-border/60">
                <CardContent className="p-6 md:p-8">
                  <h3 className="text-xl font-bold mb-6 flex items-center gap-2" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
                    <Clock className="w-5 h-5 text-[#1B3B6F]" />
                    Generation History
                  </h3>

                  {isAuthenticated && historyQuery.isLoading ? (
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {Array.from({ length: 4 }).map((_, i) => (
                        <Card key={i} className="overflow-hidden">
                          <div className="aspect-square bg-secondary/50 animate-pulse" />
                          <div className="p-3 space-y-2">
                            <div className="h-3 bg-secondary/80 rounded w-3/4 animate-pulse" />
                            <div className="h-3 bg-secondary/80 rounded w-1/2 animate-pulse" />
                          </div>
                        </Card>
                      ))}
                    </div>
                  ) : isAuthenticated && historyQuery.isError ? (
                    <div className="text-center py-12">
                      <Clock className="w-8 h-8 text-red-400/60 mx-auto mb-3" />
                      <p className="text-sm text-muted-foreground">Unable to load history. Showing session logos below.</p>
                    </div>
                  ) : displayedLogos.length > 0 ? (
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {displayedLogos.map((logo, index) => (
                        <motion.div
                          key={logo.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="overflow-hidden hover:shadow-md transition-shadow duration-200">
                            <div className="aspect-square bg-secondary/50">
                              <img
                                src={logo.imageUrl}
                                alt={`Logo - ${logo.prompt}`}
                                className="w-full h-full object-contain p-2"
                              />
                            </div>
                            <div className="p-3 space-y-1">
                              <p className="text-xs text-muted-foreground line-clamp-1">
                                {logo.prompt}
                              </p>
                              <div className="flex flex-wrap gap-1">
                                <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                                  {logo.style}
                                </Badge>
                                <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                                  {logo.colorPalette}
                                </Badge>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="w-full mt-1 text-[10px] h-6 gap-1 text-[#1B3B6F] hover:bg-[#1B3B6F]/10"
                                onClick={() => handleDownload(logo.imageUrl)}
                              >
                                <Download className="w-3 h-3" />
                                Download
                              </Button>
                            </div>
                          </Card>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Clock className="w-8 h-8 text-muted-foreground/40 mx-auto mb-3" />
                      <p className="text-sm text-muted-foreground">
                        No logos generated yet. Create your first logo above!
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/40 py-8 mt-auto">
        <div className="container text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-6 h-6 rounded-md bg-[#0A2463] flex items-center justify-center">
              <Wand2 className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-sm font-semibold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
              LogoCraft
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            AI-powered logo generation. Design the perfect brand identity.
          </p>
        </div>
      </footer>
    </div>
  );
}
