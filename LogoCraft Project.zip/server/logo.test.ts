import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the image generation and database modules
vi.mock("./_core/imageGeneration", () => ({
  generateImage: vi.fn().mockResolvedValue({ url: "/storage/test-image.png" }),
}));

vi.mock("./db", () => ({
  saveLogo: vi.fn().mockResolvedValue(undefined),
  getUserLogos: vi.fn().mockResolvedValue([
    {
      id: 1,
      userId: 1,
      prompt: "A cool logo",
      style: "Modern",
      colorPalette: "Vibrant",
      industry: "Tech",
      imageUrl: "/storage/test-image.png",
      fileKey: "test-image.png",
      createdAt: new Date(),
    },
  ]),
}));

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "oauth",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("logo.generate", () => {
  it("generates a logo and returns success with image URL", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.logo.generate({
      prompt: "A sleek fox head",
      style: "Modern",
      colorPalette: "Vibrant",
      industry: "Tech",
    });

    expect(result.success).toBe(true);
    expect(result.imageUrl).toBe("/storage/test-image.png");
    expect(result.fileKey).toBe("test-image.png");
  });

  it("rejects empty prompt", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.logo.generate({
        prompt: "",
        style: "Modern",
        colorPalette: "Vibrant",
        industry: "Tech",
      })
    ).rejects.toThrow();
  });

  it("rejects invalid style option", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.logo.generate({
        prompt: "A logo",
        style: "InvalidStyle" as any,
        colorPalette: "Vibrant",
        industry: "Tech",
      })
    ).rejects.toThrow();
  });

  it("accepts all valid style options", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const styles = ["Modern", "Vintage", "Geometric", "Minimalist", "Bold", "Playful"];
    for (const style of styles) {
      const result = await caller.logo.generate({
        prompt: "A test logo",
        style: style as any,
        colorPalette: "Vibrant",
        industry: "Tech",
      });
      expect(result.success).toBe(true);
    }
  });

  it("accepts all valid color palette options", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const palettes = ["Monochrome", "Vibrant", "Pastel", "Earth Tones", "Neon"];
    for (const palette of palettes) {
      const result = await caller.logo.generate({
        prompt: "A test logo",
        style: "Modern",
        colorPalette: palette as any,
        industry: "Tech",
      });
      expect(result.success).toBe(true);
    }
  });

  it("accepts all valid industry options", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const industries = ["Tech", "Food", "Fashion", "Finance", "Health", "Creative"];
    for (const industry of industries) {
      const result = await caller.logo.generate({
        prompt: "A test logo",
        style: "Modern",
        colorPalette: "Vibrant",
        industry: industry as any,
      });
      expect(result.success).toBe(true);
    }
  });
});

describe("logo.history", () => {
  it("returns user's logo history", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.logo.history();

    expect(result.success).toBe(true);
    expect(result.logos).toHaveLength(1);
    expect(result.logos[0]?.style).toBe("Modern");
    expect(result.logos[0]?.colorPalette).toBe("Vibrant");
    expect(result.logos[0]?.industry).toBe("Tech");
  });
});
